import {VscArrowLeft} from 'react-icons/vsc';

function BackButton() {
  return (
    <>
      <VscArrowLeft className='backButton'></VscArrowLeft>
    </>
  );
}

export default BackButton;
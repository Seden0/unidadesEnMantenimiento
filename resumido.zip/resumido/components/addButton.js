import { PlusCircleFill } from 'react-bootstrap-icons';

function AddButton() {
  return (
    <>
      <PlusCircleFill className='addPlusFill'></PlusCircleFill>
    </>
  );
}

export default AddButton;
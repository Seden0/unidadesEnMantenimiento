import { BsFillStarFill } from "react-icons/bs"
import { VscArrowSwap } from "react-icons/vsc"
import { Button } from "react-bootstrap";
function MenuCrono() {
    return (
        <>
            <div className="cardCronogramaInfo">

                <BsFillStarFill className="star-icon"></BsFillStarFill>

                <Button variant="outline-secondary">Quitar de favoritos</Button>

                <VscArrowSwap className="return-icon"></VscArrowSwap>

                <Button variant="outline-secondary">Invertir ruta</Button>
            </div><br></br>
            <div>
                <h2 className="text-center">Próxima Salida</h2>
            </div>
        </>
    );
}

export default MenuCrono;